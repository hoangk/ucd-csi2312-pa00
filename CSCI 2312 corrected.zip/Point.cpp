// I just implement all the function in the Point.h to this
// gotta fill in the function definition
#include "Point.h"
#include <cmath>



namespace Clustering {

    Clustering::Point::Point::(int initDim) {
        m_Dims = initDim;
         
    }

// create an array, have pointer point at array

    Clustering::Point::Point(int i, double *pDouble) {

    }

    Clustering::Point::Point(const Point &point) {

    }
    // destructor
    Point::~Point() {

    }

    void Point::setValues(int i, double d) {

    }

    double Point::getValues(int i) const {
        return 0;
    }

    Clustering::Point &Clustering::Point::operator=(const Clustering::Point &point) {

    }

    bool operator=(const Point &a, const Point &b) {
        bool equal = false;

        if (a.getDims() == b.getDims()) {
            bool equal = true;
            double *avals = a.getValues(),
                    *bvals = b.getValues();
            for (int i = 0; i < a.getDims() ; i ++) {
                if (avals[i] != bvals[i]) {
                    equal = false;
                    break;
                }
            }
        }

        return equal;
    }

    double Clustering::Point::distanceTo(const Clustering::Point &point) const {
        return 0;
    }

    Clustering::Point &Clustering::Point::operator*=(double d) {
        return <#initializer#>;
    }

    Clustering::Point &Clustering::Point::operator/=(double d) {
        return <#initializer#>;
    }

    const Clustering::Point Clustering::Point::operator*(double d) const {
        return Clustering::Point(0);
    }

    const Clustering::Point Clustering::Point::operator/(double d) const {
        return Clustering::Point(0);
    }

    Clustering::Point &Clustering::operator+=(Clustering::Point &point, const Clustering::Point &point1) {
        return <#initializer#>;
    }

    Clustering::Point &Clustering::operator-=(Clustering::Point &point, const Clustering::Point &point1) {
        return <#initializer#>;
    }

    const Clustering::Point Clustering::operator+(const Clustering::Point &point, const Clustering::Point &point1) {
        return Clustering::Point(0);
    }

    const Clustering::Point Clustering::operator-(const Clustering::Point &point, const Clustering::Point &point1) {
        return Clustering::Point(0);
    }

    bool Clustering::operator==(const Clustering::Point &point, const Clustering::Point &point1) {
        return false;
    }

    bool Clustering::operator!=(const Clustering::Point &point, const Clustering::Point &point1) {
        return false;
    }

    bool Clustering::operator<(const Clustering::Point &point, const Clustering::Point &point1) {
        return false;
    }

    bool Clustering::operator>(const Clustering::Point &point, const Clustering::Point &point1) {
        return false;
    }

    bool Clustering::operator<=(const Clustering::Point &point, const Clustering::Point &point1) {
        return false;
    }

    bool Clustering::operator>=(const Clustering::Point &point, const Clustering::Point &point1) {
        return false;
    }

    std::ostream &Clustering::operator<<(std::ostream &ostream, const Clustering::Point &point) {
        return <#initializer#>;
    }

    std::istream &Clustering::operator>>(std::istream &istream, Clustering::Point &point) {
        return <#initializer#>;
    }



}
